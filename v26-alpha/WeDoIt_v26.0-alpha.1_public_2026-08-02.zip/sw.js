"use strict";
const VERSION = "v26.0-alpha.1";
const CACHE = "wedoit-" + VERSION;
const SHELL = ["./", "./index.html", "./app-shell-v260a1.js", "./core-v260a1.js", "./dashboard-v260a1.js"];
self.addEventListener("install", event => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE).then(cache => Promise.allSettled(SHELL.map(url => cache.add(new Request(url, { cache: "reload" }))))).catch(() => {}));
});
self.addEventListener("activate", event => event.waitUntil((async () => {
  try { await Promise.all((await caches.keys()).filter(key => key !== CACHE).map(key => caches.delete(key))); } catch (_) {}
  await self.clients.claim();
})()));
self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  let url; try { url = new URL(request.url); } catch (_) { return; }
  if (url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    try {
      const fresh = await fetch(request);
      if (fresh.ok) caches.open(CACHE).then(cache => cache.put(request, fresh.clone())).catch(() => {});
      return fresh;
    } catch (_) {
      const cached = await caches.match(request);
      if (cached) return cached;
      if (request.mode === "navigate") return (await caches.match("./index.html")) || new Response("오프라인 사본이 없습니다.", { status: 503 });
      return new Response("offline", { status: 503 });
    }
  })());
});

